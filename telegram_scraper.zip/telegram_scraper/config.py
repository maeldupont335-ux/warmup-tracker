# ============================================================
#  CONFIGURATION TELEGRAM SCRAPER
# ============================================================

API_ID   = 36977122
API_HASH = "605773c1b40159ed7ee5750fd2e4fb4c"
PHONE    = "+33"          # <-- Mets ton numero ici ex: "+33612345678"

# Canal a scraper (ton canal)
TARGET   = "@sfs_france"

# Fichiers de sortie
OUTPUT_CSV   = "output/membres.csv"
OUTPUT_EXCEL = "output/membres.xlsx"

# Delai entre requetes (secondes)
DELAY = 1.5
