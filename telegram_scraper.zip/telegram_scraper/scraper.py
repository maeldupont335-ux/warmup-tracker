"""
Telegram Member Scraper
Scrape les membres d'un canal/groupe public via l'API officielle Telegram.
"""

import asyncio
import csv
import os
import sys
from datetime import datetime

from telethon import TelegramClient
from telethon.errors import (
    ChatAdminRequiredError,
    FloodWaitError,
    PeerFloodError,
    SessionPasswordNeededError,
)
from telethon.tl.functions.channels import GetParticipantsRequest
from telethon.tl.types import (
    ChannelParticipantsSearch,
    UserStatusEmpty,
    UserStatusLastMonth,
    UserStatusLastWeek,
    UserStatusOffline,
    UserStatusOnline,
    UserStatusRecently,
)

try:
    import openpyxl
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

from config import API_ID, API_HASH, PHONE, TARGET, OUTPUT_CSV, OUTPUT_EXCEL, DELAY


def format_status(status) -> str:
    if isinstance(status, UserStatusOnline):
        return "En ligne"
    if isinstance(status, UserStatusRecently):
        return "Recemment"
    if isinstance(status, UserStatusLastWeek):
        return "La semaine derniere"
    if isinstance(status, UserStatusLastMonth):
        return "Le mois dernier"
    if isinstance(status, UserStatusOffline):
        return status.was_online.strftime("%Y-%m-%d %H:%M") if status.was_online else "Hors ligne"
    return "Inconnu"


def parse_user(user) -> dict:
    return {
        "id":        user.id,
        "username":  user.username or "",
        "prenom":    user.first_name or "",
        "nom":       user.last_name or "",
        "telephone": user.phone or "",
        "bot":       "Oui" if user.bot else "Non",
        "verifie":   "Oui" if user.verified else "Non",
        "statut":    format_status(user.status),
        "scrape_le": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }


async def scrape(client: TelegramClient) -> list:
    print(f"\n[->] Resolution de la cible : {TARGET}")
    try:
        entity = await client.get_entity(TARGET)
    except ValueError:
        print("[X] Canal/groupe introuvable. Verifie TARGET dans config.py")
        return []

    title = getattr(entity, "title", TARGET)
    print(f"[OK] Connecte a : {title}")

    members = []
    offset  = 0
    limit   = 200
    total   = None

    print("[->] Recuperation des membres en cours...\n")

    while True:
        try:
            result = await client(GetParticipantsRequest(
                channel=entity,
                filter=ChannelParticipantsSearch(""),
                offset=offset,
                limit=limit,
                hash=0,
            ))
        except ChatAdminRequiredError:
            print("[X] Acces refuse : tu dois etre admin pour lister les membres.")
            break
        except FloodWaitError as e:
            print(f"[!] Rate-limit Telegram - attente {e.seconds}s...")
            await asyncio.sleep(e.seconds)
            continue
        except PeerFloodError:
            print("[X] Trop de requetes. Reessaie dans quelques heures.")
            break

        if not result.users:
            break

        if total is None:
            total = result.count
            print(f"    Total membres : {total}")

        for user in result.users:
            if not user.is_self:
                members.append(parse_user(user))

        offset += len(result.users)
        pct = (offset / total * 100) if total else 0
        print(f"    [{offset}/{total}] {pct:.1f}% - {len(members)} membres recuperes", end="\r")

        if offset >= total or len(result.users) < limit:
            break

        await asyncio.sleep(DELAY)

    print(f"\n\n[OK] Scraping termine - {len(members)} membres collectes")
    return members


def save_csv(members: list, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not members:
        return
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=members[0].keys())
        writer.writeheader()
        writer.writerows(members)
    print(f"[OK] CSV enregistre  : {path}")


def save_excel(members: list, path: str) -> None:
    if not EXCEL_AVAILABLE:
        print("[!] openpyxl non installe - export Excel ignore.")
        return
    os.makedirs(os.path.dirname(path), exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Membres"

    if not members:
        wb.save(path)
        return

    headers = list(members[0].keys())
    ws.append(headers)

    from openpyxl.styles import Font, PatternFill, Alignment
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="2563EB")
    for cell in ws[1]:
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = Alignment(horizontal="center")

    for m in members:
        ws.append(list(m.values()))

    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)

    wb.save(path)
    print(f"[OK] Excel enregistre : {path}")


async def main():
    if not API_ID or not API_HASH or not PHONE or PHONE == "+33":
        print("[X] Remplis ton numero de telephone dans config.py")
        print("    PHONE = \"+33612345678\"")
        sys.exit(1)

    print("=" * 50)
    print("  Telegram Member Scraper - @sfs_france")
    print("=" * 50)

    client = TelegramClient("session_scraper", API_ID, API_HASH)
    await client.start(phone=PHONE)

    me = await client.get_me()
    print(f"[OK] Connecte en tant que : {me.first_name} (@{me.username})")

    members = await scrape(client)

    if members:
        save_csv(members, OUTPUT_CSV)
        save_excel(members, OUTPUT_EXCEL)
        print(f"\n[OK] Fichiers disponibles dans : output/")
    else:
        print("\n[!] Aucun membre recupere.")

    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
